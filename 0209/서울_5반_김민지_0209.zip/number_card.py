import sys
sys.stdin = open("sample_input.txt", "r")

T = int(input())

for t in range(1, T+1):
    n = int(input())
    cards = str(input())

    all_dict = {cards[0]: 1}
    max_card = cards[0]
    max_cnt = 1

    for card in cards[1:]:
        all_dict[card] = all_dict.get(card, 0) + 1
        cnt = all_dict[card]

        if cnt > max_cnt:
            max_card = card
            max_cnt = cnt

        elif cnt == max_cnt and card > max_card:
            max_card = card
            max_cnt = cnt

    print("#%d %s %d" % (t, max_card, max_cnt))

