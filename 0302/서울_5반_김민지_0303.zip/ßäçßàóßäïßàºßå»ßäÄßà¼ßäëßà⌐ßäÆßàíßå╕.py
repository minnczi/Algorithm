import sys
sys.stdin = open('min_sum_input.txt', 'r')

T = int(input())

def find_min_sum(visited, total, row, col):
    visited[col] = 1
    total += arr[row][col]

    # 다음줄 탐색
    r = row + 1
    if r == N:
        global minimum
        if total < minimum:
            minimum = total
        return

    for c in range(N):
        if not visited[c]:
            find_min_sum(visited, total, r, c)
            print("here")
            print(visited, total, row, col)
    


for tc in range(1, T+1):
    N = int(input())
    arr = [list(map(int, input().split())) for _ in range(N)]
    minimum = 500

    total = 0
    r = 0
    for c in range(N):
        visited = [0] * N
        find_min_sum(visited, total, r, c)
    print(minimum)